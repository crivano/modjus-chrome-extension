// Exemplo de código do background.js
chrome.runtime.onInstalled.addListener(() => {
  console.log('A extensão foi instalada!');
});

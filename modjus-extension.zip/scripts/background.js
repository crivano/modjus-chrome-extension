chrome.runtime.onInstalled.addListener(() => {
  console.log('A extensão foi instalada!');
});


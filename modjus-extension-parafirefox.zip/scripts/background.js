// Exemplo de código do background.js
browser.runtime.onInstalled.addListener(() => {
  console.log('A extensão foi instalada!');
});
